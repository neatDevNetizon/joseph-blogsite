<nav class="navbar-default navbar-static-side" id="leftsidebar" role="navigation"> 
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <a class="logos" href="/admin">LOGO</a>
                </li>
                
                <div class="nav metismenu nab-scroll">
                    <li>
                        <a href="/admin"><img src="/App/View/img/Commode2.svg">&nbsp;<span class="nav-label">Dashboard</span></a>
                    </li>
                    <li>
                        <a href="/admin/new"><img src="/App/View/img/Eject.svg">&nbsp;<span class="nav-label">New Blog</span></a>
                    </li>
                    <li>
                        <a href="/admin/list"><img src="/App/View/img/Ladder.svg">&nbsp;<span class="nav-label">Blog List</span></a>
                    </li>
                </div>
            </ul>

        </div>
    </nav>

    <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                
                <div class="nav navbar-top-links navbar-header d-flex">
                    <li class="m-logobox">
                        <img class="w-img" src="img/new/Logo_mobile.png">
                    </li>
                    <li class="top-bth">
                        <button class="navbar-toggler" type="button" id="side-btn-top">
                            <img src="/App/View/img/Angle-double-right.svg">    
                        </button>
                    </li>
                    
                   
                </div>
                <ul class="nav navbar-top-links navbar-right">
                   
                    <li>
                        <a href="#">
                            <img src="/App/View/img/Sign-out.svg">&nbsp;<span class="txt-d-none">Log out</span>
                        </a>
                    </li>
                </ul>

            </nav>
        </div>