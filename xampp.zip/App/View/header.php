<div class="navbars flex-around">
    <a class="logos" href="/">LOGO</a>
    <ul class="nav_items responsive-before">
        <a class="nav_item" href="books">Books</a>
        <a class="nav_item" href="record">Record Store</a>
        <a class="nav_item" href="vinyl">Vinyl Records Market</a>
    </ul>
    <div class="ham_btn flex-between flex-column responsive-after" onclick="hamb_toggle()">
        <div></div>
        <div></div>
        <div></div>
    </div>
    <ul class="nav_items_after flex-between flex-column responsive-after">
        <a class="nav_item" href="books">Books</a>
        <a class="nav_item" href="record">Record Store</a>
        <a class="nav_item" href="vinyl">Vinyl Records Market</a>
    </ul>
</div>